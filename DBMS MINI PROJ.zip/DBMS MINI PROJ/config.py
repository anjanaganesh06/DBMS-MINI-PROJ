import os

class Config:
    MYSQL_HOST = 'localhost'  # Change to your MySQL host
    MYSQL_USER = 'root'  # Change to your MySQL username
    MYSQL_PASSWORD = 'Grape2004'  # Change to your MySQL password
    MYSQL_DB = 'dbmsminiproj'
