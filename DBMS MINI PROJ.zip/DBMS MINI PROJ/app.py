from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
from config import Config
from functools import wraps
import yfinance as yf

app = Flask(__name__)
app.config.from_object(Config)
app.secret_key = 'your_secret_key'

# Initialize MySQL
mysql = MySQL(app)

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('logged_in'):
            print("Not logged in!")
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Route to render home page
@app.route('/')
def index():
    return render_template('index.html')

# Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username'].strip()  # Strip leading/trailing spaces
        password = request.form['password'].strip()  # Strip leading/trailing spaces

        # Check credentials in the database
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cur.fetchone()
        cur.close()

        
        if user:
            print(f"Stored password: {user[3]}")  
            # Compare the provided password with the stored password (plain text)
            if user[3] == password:
                session['logged_in'] = True
                session['username'] = user[1]  # Assuming index 1 is username
                flash('You have been logged in!', 'success')
                print(f"Session data: {session}")  # Print session for debugging
                return redirect(url_for('services_provided'))  # Redirect to services page after successful login
            else:
                error = 'Invalid credentials. Please try again.'
                flash(error, 'danger')
        else:
            error = 'Invalid credentials. Please try again.'
            flash(error, 'danger')

    return render_template('login.html', error=error)


# Sign Up Route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    error = None
    if request.method == 'POST':
        username = request.form['username'].strip()  # Strip leading/trailing spaces
        email = request.form['email'].strip()
        password = request.form['password'].strip()

        # Check if the username already exists
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s", (username,))
        existing_user = cur.fetchone()
        
        if existing_user:
            error = "Username already exists. Please choose a different one."
        else:
            # Insert new user into the database with plain text password
            cur.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
                        (username, email, password))
            mysql.connection.commit()
            cur.close()
            
            flash('Account created successfully! You can now log in.', 'success')
            return redirect(url_for('login'))  # Redirect to the login page after signup
    
    return render_template('signup.html', error=error)


# Logout Route
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('username', None)  # Clear the username from session
    flash('You have been logged out!', 'success')
    return redirect(url_for('login'))


### User and Stock CRUD Operations ###

@app.route('/services_provided')
@login_required  # Ensure the user must be logged in to access this page
def services_provided():
    return render_template('services.html')


@app.route('/add_user', methods=['GET', 'POST'])
@login_required

def add_user():
    if request.method == 'POST':
        # Retrieve form data
        user_id = request.form['user_id']
        risk_profile = request.form['risk_profile']
        account_details = request.form['account_details']
        name = request.form['name']
        account_id = request.form.get('account_id', None)
        acc_type = request.form.get('acc_type', None)
        acc_status = request.form.get('acc_status', None)
        opening_date = request.form.get('opening_date', None)
        email_id = request.form.get('email_id', None)
        phone_no = request.form.get('phone_no', None)

        # Insert the user into MySQL
        cur = mysql.connection.cursor()
        
        # Insert data into user table
        cur.execute(
            """
            INSERT INTO user (user_id, risk_profile, name, account_id, acc_type, account_details, acc_status, opening_date) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (user_id, risk_profile, name, account_id, acc_type, account_details, acc_status, opening_date)
        )

        # Insert email if provided
        if email_id:
            cur.execute(
                "INSERT INTO user_emailid (user_id, email_id) VALUES (%s, %s)",
                (user_id, email_id)
            )

        # Insert phone number if provided
        if phone_no:
            cur.execute(
                "INSERT INTO user_phno (user_id, phone_no) VALUES (%s, %s)",
                (user_id, phone_no)
            )

        # Commit changes and close the cursor
        mysql.connection.commit()
        cur.close()

        return redirect(url_for('view_users'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT DISTINCT risk_profile FROM user")
    risk_profiles = [row[0] for row in cur.fetchall()]
    
    cur.execute("SELECT DISTINCT name FROM user")
    names = [row[0] for row in cur.fetchall()]
    cur.close()

    # Render the form template if request method is GET
    return render_template('add_user.html', risk_profiles=risk_profiles, names=names)


# Update user details function
def update_user_details(user_id, name, risk_profile, account_id, acc_type, account_details, acc_status, opening_date, email_id, phone_no):
    # Get a database connection
    connection = mysql.connection
    cursor = connection.cursor()

    try:
        # Call the stored procedure to update user details
        cursor.callproc('update_user_details', [
            user_id, name, risk_profile, account_id, acc_type, account_details, 
            acc_status, opening_date, email_id, phone_no
        ])
        connection.commit()  # Commit the transaction
    except Exception as e:
        print(f"Error occurred: {e}")
    finally:
        cursor.close()  # Close cursor
        connection.close()  # Close connection
# # Route to edit a user
# @app.route('/edit_user/<string:user_id>', methods=['GET', 'POST'])
# def edit_user(user_id):
#     cursor = mysql.connection.cursor()

#     # Check if the form was submitted to update the user
#     if request.method == 'POST':
#         name = request.form['name']
#         risk_profile = request.form['risk_profile']
#         acc_type = request.form['acc_type']
#         acc_details = request.form['acc_details']
#         acc_status = request.form['acc_status']
#         opening_date=request.form['opening_date']
#         email = request.form['email']
#         phone = request.form['phone']

#         cursor.execute("""
#             UPDATE user
#             SET name = %s, risk_profile = %s, acc_type = %s, account_details = %s,
#                 acc_status = %s,opening_date=%s, email = %s, phone = %s
#             WHERE user_id = %s
#         """, (name, risk_profile, acc_type, acc_details, acc_status,opening_date, email, phone, user_id))
#         mysql.connection.commit()
#         cursor.close()

#         return redirect(url_for('view_users'))

#     # If it's a GET request, fetch the current user details to show in the form
#     cursor.execute("SELECT * FROM user WHERE user_id = %s", (user_id,))
#     user = cursor.fetchone()
#     cursor.close()

#     return render_template('edit_user.html', user=user)

from flask_mysqldb import MySQLdb

@app.route('/edit_user/<string:user_id>', methods=['GET', 'POST'])
def edit_user(user_id):
    # Use DictCursor to fetch results as dictionaries
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

    # Rest of your code remains the same
    if request.method == 'POST':
        name = request.form['name']
        risk_profile = request.form['risk_profile']
        acc_type = request.form['acc_type']
        acc_details = request.form['acc_details']
        acc_status = request.form['acc_status']
        opening_date = request.form['opening_date']
        # Update query for user table
        cursor.execute("""
            UPDATE user
            SET name = %s, risk_profile = %s, acc_type = %s, account_details = %s,
                acc_status = %s, opening_date = %s
            WHERE user_id = %s
        """, (name, risk_profile, acc_type, acc_details, acc_status, opening_date, user_id))

        # Handle emails and phones similarly, then commit changes
        # ...
        
        mysql.connection.commit()
        cursor.close()
        return redirect(url_for('view_users'))

    # Fetch user and related data as dictionaries
    cursor.execute("SELECT * FROM user WHERE user_id = %s", (user_id,))
    user = cursor.fetchone()

    # Fetch emails and phones
    cursor.execute("SELECT email_id FROM user_emailid WHERE user_id = %s", (user_id,))
    emails = [row['email_id'] for row in cursor.fetchall()]

    cursor.execute("SELECT phone_no FROM user_phno WHERE user_id = %s", (user_id,))
    phones = [row['phone_no'] for row in cursor.fetchall()]

    cursor.close()
    return render_template('edit_user.html', user=user, emails=emails, phones=phones)





@app.route('/delete_user/<user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM user WHERE user_id=%s", (user_id,))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('view_users'))

### User Email CRUD Operations ###
@app.route('/view_users')
@login_required
def view_users():
    cursor = mysql.connection.cursor()
    query = """
        SELECT u.user_id, u.risk_profile, u.name, u.account_id, u.acc_type, u.account_details, 
               u.acc_status, u.opening_date, e.email_id, p.phone_no
        FROM user u
        LEFT JOIN user_emailid e ON u.user_id = e.user_id
        LEFT JOIN user_phno p ON u.user_id = p.user_id
    """
    cursor.execute(query)
    result = cursor.fetchall()
    cursor.close()

    # Use a dictionary with composite keys of (user_id, account_id)
    users = {}
    for row in result:
        (
            user_id, risk_profile, name, account_id, acc_type, account_details, 
            acc_status, opening_date, email_id, phone_no
        ) = row

        # Use (user_id, account_id) as the composite key
        key = (user_id, account_id)

        # Initialize entry if not already present
        if key not in users:
            users[key] = {
                "user_id": user_id,
                "risk_profile": risk_profile,
                "name": name,
                "account_id": account_id,
                "acc_type": acc_type,
                "account_details": account_details,
                "acc_status": acc_status,
                "opening_date": opening_date,
                "emails": set(),
                "phones": set()
            }

        # Add email and phone numbers to the sets
        if email_id:
            users[key]["emails"].add(email_id)
        if phone_no:
            users[key]["phones"].add(phone_no)

    # Convert sets to lists for easier rendering in the template
    for user in users.values():
        user["emails"] = list(user["emails"])
        user["phones"] = list(user["phones"])

    # Render the template with users.values() to display all unique (user_id, account_id) pairs
    return render_template('view_users.html', users=users.values())
# Route to add an email for a user
@app.route('/add_email/<user_id>', methods=['GET', 'POST'])
@login_required
def add_email(user_id):
    if request.method == 'POST':
        email_id = request.form['email_id']
        cur = mysql.connection.cursor()
        cur.execute(
            "INSERT INTO user_emailid (user_id, email_id) VALUES (%s, %s)",
            (user_id, email_id)
        )
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('view_user_emails', user_id=user_id))
    return render_template('add_email.html', user_id=user_id)

# Route to view all emails of a user
@app.route('/view_user_emails/<user_id>')
@login_required
def view_user_emails(user_id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM user_emailid WHERE user_id = %s", (user_id,))
    emails = cur.fetchall()
    cur.close()
    return render_template('view_user_emails.html', user_id=user_id, emails=emails)

# Route to delete an email
@app.route('/delete_email/<user_id>/<email_id>', methods=['POST'])
@login_required
def delete_email(user_id, email_id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM user_emailid WHERE user_id = %s AND email_id = %s", (user_id, email_id))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('view_user_emails', user_id=user_id))

### User Phone Number CRUD Operations ###

# Route to add a phone number for a user
@app.route('/add_phone/<user_id>', methods=['GET', 'POST'])
@login_required
def add_phone(user_id):
    if request.method == 'POST':
        phone_number = request.form['phone_number']
        cur = mysql.connection.cursor()
        cur.execute(
            "INSERT INTO user_phno (user_id, phone_number) VALUES (%s, %s)",
            (user_id, phone_number)
        )
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('view_user_phones', user_id=user_id))
    return render_template('add_phone.html', user_id=user_id)

# Route to view all phone numbers of a user
@app.route('/view_user_phones/<user_id>')
@login_required
def view_user_phones(user_id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM user_phno WHERE user_id = %s", (user_id,))
    phones = cur.fetchall()
    cur.close()
    return render_template('view_user_phones.html', user_id=user_id, phones=phones)

# Route to delete a phone number
@app.route('/delete_phone/<user_id>/<phone_number>', methods=['POST'])
@login_required
def delete_phone(user_id, phone_number):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM user_phno WHERE user_id = %s AND phone_number = %s", (user_id, phone_number))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('view_user_phones', user_id=user_id))

# Fetch and store stock data from yfinance
def fetch_and_store_stock_data(symbol, exchange_id=None):
    # Ensure exchange_id exists in the exchange table
    if exchange_id:
        cur = mysql.connection.cursor()
        cur.execute("SELECT 1 FROM exchange WHERE exchange_id = %s", (exchange_id,))
        if cur.fetchone() is None:
            # Insert exchange_id if it does not exist
            cur.execute("INSERT INTO exchange (exchange_id) VALUES (%s)", (exchange_id,))
            mysql.connection.commit()
        cur.close()
    
    # Rest of the code to fetch stock data from yfinance
    stock = yf.Ticker(symbol)
    todays_data = stock.history(period='1d')
    
    # Extract data fields
    comp_name = stock.info.get('shortName', "N/A")[:30]
    sector = stock.info.get('sector', "N/A")[:10]
    total_shares = stock.info.get('sharesOutstanding', 0)
    market_price = todays_data['Close'].iloc[0] if not todays_data.empty else 0
    listing_date = stock.info.get('firstTradeDate', None)

    # Insert fetched data into the MySQL database
    cur = mysql.connection.cursor()
    cur.execute("""
        INSERT INTO stock (stock_id, comp_name, sector, total_share, market_price, exchange_id, listing_date)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
            comp_name = VALUES(comp_name),
            sector = VALUES(sector),
            total_share = VALUES(total_share),
            market_price = VALUES(market_price),
            exchange_id = VALUES(exchange_id),
            listing_date = VALUES(listing_date)
    """, (symbol, comp_name, sector, total_shares, market_price, exchange_id, listing_date))
    mysql.connection.commit()
    cur.close()



# Prepopulate stock data
with app.app_context():
    fetch_and_store_stock_data(symbol="NVDA", exchange_id="NASDAQ")
    print("Stock data for NVDA prepopulated.")

### Stock CRUD Operations ###

@app.route('/view_order_stock', methods=['GET', 'POST'])
def view_order_form():
    order_details = None
    if request.method == 'POST':
        stock_id = request.form['stock_id']
        order_id = request.form['order_id']
        
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT get_full_order_stock_details(%s, %s)", (stock_id, order_id))
        result = cursor.fetchone()
        cursor.close()
        
        if result:
            order_details_str = result[0]  # Retrieve as a string
            # Manual parsing to convert to a dictionary
            order_details = {}
            for item in order_details_str.split(', '):
                if ': ' in item:
                    key, value = item.split(': ', 1)
                    order_details[key.strip()] = value.strip()
            if not order_details:
                flash('No matching records found for the provided stock_id and order_id', 'warning')

    return render_template('view_order_details.html', order_details=order_details)



@app.route('/add_stock', methods=['GET', 'POST'])
@login_required
def add_stock():
    # Establish a cursor for database interaction
    cursor = mysql.connection.cursor()

    # Fetch all exchange IDs from the 'exchange' table
    cursor.execute("SELECT exchange_id FROM exchange")
    exchanges = cursor.fetchall()

    # Handle form submission
    if request.method == 'POST':
        # Extract form data
        stock_id = request.form['stock_id']
        comp_name = request.form['comp_name']
        sector = request.form['sector']
        total_share = request.form['total_share']
        market_price = request.form['market_price']
        exchange_id = request.form['exchange_id']
        listing_date = request.form['listing_date']

        try:
            # Insert the new stock into the database
            cursor.execute("""
                INSERT INTO stock (stock_id, comp_name, sector, total_share, market_price, exchange_id, listing_date)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (stock_id, comp_name, sector, total_share, market_price, exchange_id, listing_date))

            # Commit the transaction
            mysql.connection.commit()

            # Provide a success message to the user
            flash("Stock added successfully!", "success")
        except Exception as e:
            # Rollback in case of error and flash a message
            mysql.connection.rollback()
            flash(f"Error adding stock: {str(e)}", "danger")

        return redirect(url_for('view_stocks'))  # Redirect to the view stocks page after successful insertion

    # If it's a GET request, just render the form
    return render_template('add_stock.html', exchanges=exchanges)



@app.route('/view_stocks')
@login_required
def view_stocks():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM stock")
    stocks = cur.fetchall()
    cur.close()
    return render_template('view_stocks.html', stocks=stocks)

# Route to edit stock details
@app.route('/edit_stock/<stock_id>', methods=['GET', 'POST'])
@login_required
def edit_stock(stock_id):
    cur = mysql.connection.cursor()
    if request.method == 'POST':
        comp_name = request.form['comp_name']
        sector = request.form['sector']
        total_share = request.form['total_share']
        market_price = request.form['market_price']
        exchange_id = request.form['exchange_id']
        listing_date = request.form['listing_date']

        cur.execute("""
            UPDATE stock SET comp_name=%s, sector=%s, total_share=%s, market_price=%s, exchange_id=%s, listing_date=%s
            WHERE stock_id=%s
        """, (comp_name, sector, total_share, market_price, exchange_id, listing_date, stock_id))
        mysql.connection.commit()
        cur.close()

        return redirect(url_for('view_stocks'))
    else:
        cur.execute("SELECT * FROM stock WHERE stock_id=%s", (stock_id,))
        stock = cur.fetchone()
        cur.close()

        return render_template('edit_stock.html', stock=stock)
    
# Route to delete a stock entry
@app.route('/delete_stock/<stock_id>', methods=['POST'])
@login_required
def delete_stock_html(stock_id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM stock WHERE stock_id=%s", (stock_id,))
    mysql.connection.commit()
    cur.close()

    return redirect(url_for('view_stocks'))
    
### Portfolio CRUD Operations ###

@app.route('/add_portfolio', methods=['GET', 'POST'])
@login_required
def add_portfolio():
    cur = mysql.connection.cursor()
    
    if request.method == 'POST':
        portfolio_id = request.form['portfolio_id']
        user_id = request.form['user_id']
        portfolio_value = request.form.get('portfolio_value', None)
        portfolio_name = request.form.get('portfolio_name', None)
        risk_level = request.form.get('risk_level', None)
        created_date = request.form.get('created_date', None)
        stock_id = request.form.get('stock_id', None)

        cur.execute(""" 
            INSERT INTO portfolio (portfolio_id, user_id, portfolio_value, portfolio_name, risk_level, created_date, stock_id)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (portfolio_id, user_id, portfolio_value, portfolio_name, risk_level, created_date, stock_id))
        
        if stock_id:
            cur.execute("INSERT INTO contains (portfolio_id, stock_id) VALUES (%s, %s)", (portfolio_id, stock_id))
        
        mysql.connection.commit()
        cur.close()
        
        return redirect(url_for('view_portfolios'))
    
    cur.execute("SELECT user_id, name FROM user")
    users = cur.fetchall()
    cur.execute("SELECT stock_id, comp_name FROM stock")
    stocks = cur.fetchall()
    cur.close()
    
    return render_template('add_portfolios.html', users=users, stocks=stocks)

@app.route('/edit_portfolio/<portfolio_id>', methods=['GET', 'POST'])
@login_required
def edit_portfolio(portfolio_id):
    cur = mysql.connection.cursor()

    if request.method == 'POST':
        # Fetch updated data from the form
        portfolio_name = request.form['portfolio_name']
        portfolio_value = request.form['portfolio_value']
        risk_level = request.form['risk_level']
        created_date = request.form['created_date']
        stock_id = request.form['stock_id']

        # Update portfolio in the database
        cur.execute("""
            UPDATE portfolio 
            SET portfolio_name = %s, portfolio_value = %s, risk_level = %s, 
                created_date = %s, stock_id = %s 
            WHERE portfolio_id = %s
        """, (portfolio_name, portfolio_value, risk_level, created_date, stock_id, portfolio_id))

        mysql.connection.commit()

        # Redirect to view the updated portfolio page
        return redirect(url_for('view_portfolio', portfolio_id=portfolio_id))

    # Fetch the current portfolio details
    cur.execute("SELECT * FROM portfolio WHERE portfolio_id = %s", (portfolio_id,))
    portfolio = cur.fetchone()

    # Handle the case where portfolio doesn't exist
    if portfolio is None:
        flash('Portfolio not found.', 'error')
        return redirect(url_for('portfolio_list'))

    # Fetch available stocks for the dropdown
    cur.execute("SELECT stock_id AS id FROM stock")
    stocks = cur.fetchall()  # Retrieve all stock data
    cur.close()

    print("Fetched portfolio:", portfolio)  # For debugging
    print("Fetched stocks:", stocks)  # For debugging

    return render_template('edit_portfolio.html', portfolio=portfolio, stocks=stocks)


@app.route('/view_portfolio', methods=['GET'])
@login_required
def view_portfolio():
    # Fetch all portfolios
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM portfolio")
    portfolios = cur.fetchall()
    cur.close()
    return render_template('view_portfolios.html', portfolios=portfolios)









@app.route('/delete_portfolio/<portfolio_id>', methods=['POST'])
@login_required
def delete_portfolio(portfolio_id):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM portfolio WHERE portfolio_id = %s", (portfolio_id,))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('view_portfolios'))





@app.route('/update_user_status', methods=['POST'])
def update_user_status():
    user_id = request.form['user_id']
    new_status = request.form['acc_status']  # This should come from the form

    # Check if the new status is a valid ENUM value
    valid_statuses = ['closed', 'active', 'pending']
    if new_status not in valid_statuses:
        flash(f'Invalid status: {new_status}', 'danger')
        return redirect(url_for('view_users'))  # Redirect to the users view

    # Proceed to update the user's status
    cursor = mysql.connection.cursor()
    cursor.execute("UPDATE user SET acc_status = %s WHERE user_id = %s", (new_status, user_id))
    mysql.connection.commit()
    cursor.close()

    flash(f'User {user_id} status updated to {new_status}', 'success')
    
    # Trigger to update portfolios will automatically run here due to the trigger in the database
    return redirect(url_for('view_users'))

# @app.route('/view_order_stock', methods=['GET', 'POST'])
# @login_required
# def view_order_stock():
#     # Get `stock_id` and `order_id` from query parameters or form data
#     stock_id = request.args.get('stock_id') or request.form.get('stock_id')
#     order_id = request.args.get('order_id') or request.form.get('order_id')

#     # Ensure both `stock_id` and `order_id` are provided
#     if not stock_id or not order_id:
#         return "Please provide both stock_id and order_id.", 400

#     # Query the database for order and stock details
#     cur = mysql.connection.cursor()
#     try:
#         # SQL query to join buy_sell, stock, and order_table
#         cur.execute("""
#             SELECT 
#                 ot.order_id, ot.order_type, ot.exchange_id, ot.qty, ot.price, 
#                 ot.order_status, ot.date_and_time, s.stock_id, s.comp_name, 
#                 s.sector, s.total_share, s.market_price, s.listing_date
#             FROM buy_sell bs
#             JOIN order_table ot ON bs.order_id = ot.order_id
#             JOIN stock s ON bs.stock_id = s.stock_id
#             WHERE bs.stock_id = %s AND bs.order_id = %s
#         """, (stock_id, order_id))

#         # Fetch result
#         order_details = cur.fetchone()

#         # Handle case where no matching record is found
#         if not order_details:
#             return "No matching records found for the provided stock_id and order_id.", 404

#     except Exception as e:
#         print("Database error:", e)
#         return "Database error occurred", 500
#     finally:
#         cur.close()

#     # Render the result in a template
#     return render_template('view_order_details.html', order_details=order_details)


@app.route('/view_exchanges')
@login_required
def view_exchanges():
    try:
        # Create a cursor to interact with the database
        cur = mysql.connection.cursor()
        
        # Execute a query to fetch all exchanges
        cur.execute("SELECT * FROM exchange")
        
        # Fetch all the rows from the executed query
        exchanges = cur.fetchall()
        
        # Debug: print the fetched exchanges
        print(f"Exchanges: {exchanges}")
        
    except Exception as e:
        # Print any exception that occurs during the query execution
        print(f"An error occurred: {e}")
        exchanges = []  # Fallback to an empty list if an error occurs
    finally:
        # Ensure the cursor is closed after the query execution
        cur.close()
    
    # Render the template with the list of exchanges
    return render_template('list_exchanges.html', exchanges=exchanges)

# Route to add a new exchange
@app.route('/add_exchange', methods=['GET', 'POST'])
def add_exchange():
    if request.method == 'POST':
        exchange_id = request.form['exchange_id']
        currency = request.form['currency']
        exchange_name = request.form['exchange_name']
        country = request.form['country']
        operating_hours = request.form['operating_hours']

        cursor = mysql.connection.cursor()
        cursor.execute("""
            INSERT INTO exchange (exchange_id, currency, exchange_name, country, operating_hours)
            VALUES (%s, %s, %s, %s, %s)
        """, (exchange_id, currency, exchange_name, country, operating_hours))
        mysql.connection.commit()  # Commit the transaction
        cursor.close()
        return redirect(url_for('view_exchanges'))

    return render_template('add_exchange.html')

# Route to edit an exchange
@app.route('/edit_exchange/<string:exchange_id>', methods=['GET', 'POST'])
def edit_exchange(exchange_id):
    cursor = mysql.connection.cursor()

    # Check if the form was submitted to update the exchange
    if request.method == 'POST':
        currency = request.form['currency']
        exchange_name = request.form['exchange_name']
        country = request.form['country']
        operating_hours = request.form['operating_hours']

        cursor.execute("""
            UPDATE exchange 
            SET currency = %s, exchange_name = %s, country = %s, operating_hours = %s
            WHERE exchange_id = %s
        """, (currency, exchange_name, country, operating_hours, exchange_id))
        mysql.connection.commit()
        cursor.close()

        return redirect(url_for('view_exchanges'))

    # If it's a GET request, fetch the current exchange details to show in the form
    cursor.execute("SELECT * FROM exchange WHERE exchange_id = %s", (exchange_id,))
    exchange = cursor.fetchone()
    cursor.close()

    return render_template('edit_exchange.html', exchange=exchange)


# Route to delete an exchange
@app.route('/delete_exchange/<exchange_id>', methods=['GET','POST'])
def delete_exchange(exchange_id):
    cursor = mysql.connection.cursor()
    cursor.execute("DELETE FROM exchange WHERE exchange_id = %s", (exchange_id,))
    mysql.connection.commit()  # Commit the transaction
    cursor.close()
    return redirect(url_for('view_exchanges'))
# Route to view transactions
@app.route('/add_transaction', methods=['GET', 'POST'])
@login_required
def add_transaction():
    if request.method == 'POST':
        # Retrieve form data
        order_id = request.form['order_id']
        trans_id = request.form['trans_id']
        portfolio_id = request.form.get('portfolio_id', None)
        total_amt = request.form.get('total_amt', None)
        trans_type = request.form['trans_type']
        t_date = request.form['t_date']
        qty = request.form.get('qty', None)
        price_per_share = request.form.get('price_per_share', None)

        # Insert the transaction into the transaction table
        cur = mysql.connection.cursor()

        # Insert transaction into the transaction_ table
        cur.execute(
            """
            INSERT INTO transaction_ (order_id, trans_id, portfolio_id, total_amt, trans_type, t_date, qty, price_per_share)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (order_id, trans_id, portfolio_id, total_amt, trans_type, t_date, qty, price_per_share)
        )

        # Commit the changes and close the cursor
        mysql.connection.commit()
        cur.close()

        # Redirect to view_transactions page after successful addition
        return redirect(url_for('view_transactions'))

    # Render the form template if request method is GET
    return render_template('add_transaction.html')

@app.route('/view_transactions')
@login_required
def view_transactions():
    # Fetch all transactions from the database
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM transaction_")
    transactions = cur.fetchall()
    cur.close()
    # Render the transactions view
    return render_template('view_transactions.html', transactions=transactions)

@app.route('/delete_transaction/<transaction_id>', methods=['POST'])
@login_required
def delete_transaction(transaction_id):
    try:
        # Create a cursor object to interact with the database
        cur = mysql.connection.cursor()
        
        # SQL query to delete the transaction based on the transaction_id
        cur.execute("DELETE FROM transaction_ WHERE trans_id = %s", (transaction_id,))
        
        # Commit the changes to the database
        mysql.connection.commit()
        
        # Close the cursor
        cur.close()
        
        # Redirect to the view_transactions page after successful deletion
        return redirect(url_for('view_transactions'))
    except Exception as e:
        # In case of error, print the error (you can handle this better with logging)
        print(f"Error deleting transaction: {e}")
        return redirect(url_for('view_transactions'))


@app.route('/update_portfolio_values', methods=['POST'])
@login_required
def update_portfolio_values():
    cur = mysql.connection.cursor()
    cur.execute("SELECT DISTINCT user_id FROM portfolio")
    user_ids = cur.fetchall()

    # Loop through each user_id and call the stored procedure
    for user_id in user_ids:
        try:
            # Call the stored procedure to update the portfolio value for each user
            cur.callproc('update_portfolio_value', [user_id[0]])
            mysql.connection.commit()  # Commit changes to the database
        except Exception as e:
            flash(f"Error updating portfolio for user {user_id[0]}: {str(e)}", 'warning')

    flash("Portfolio values updated successfully.", 'success')

    try:
        # In case of any database error during the process
        pass
    except mysql.connector.Error as err:
        flash(f"Database error: {str(err)}", 'warning')

    finally:
        # Close the cursor and connection
        if cur:
            cur.close()

    return redirect(url_for('view_portfolios'))  # Redirect to the view portfolios page


    
if __name__ == '__main__':
    app.run(port=5000, debug=True)  # Start the Flask app on port 5001